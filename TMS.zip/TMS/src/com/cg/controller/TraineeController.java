package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.TraineeBean;
import com.cg.service.ITraineeService;

@Controller
public class TraineeController {

	@Autowired
	ITraineeService traineeService;

	public ITraineeService getTraineeService() {
		return traineeService;
	}

	public void setTraineeService(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}

	@RequestMapping("show")
	public String startPage() {

		return "index";
	}

	@RequestMapping("deletePage")
	public String deletePage() {
		return "delete";
	}

	@RequestMapping("register")
	public String insertTrainee() {

		return "register";
	}

	@RequestMapping("retrieve")
	public String getTraineePage() {

		return "viewDetail";
	}

	@RequestMapping("modifyPage")
	public String modify() {

		return "modify";
	}

	@RequestMapping(value = "adddetails", method = RequestMethod.POST)
	public String addDetails(@ModelAttribute("trainee") TraineeBean bean,
			BindingResult result, Model model) throws Exception {

		String target = "";
		if (result.hasErrors()) {
			model.addAttribute("message", result);
			target = "error";
		} else {
			boolean isInserted = false;
			try {
				isInserted = traineeService.adddetails(bean);
				if (isInserted) {
					model.addAttribute("message", "Successfully Inserted");
					target = "success";
				} else {
					model.addAttribute("message", "Insertion Failed");
					target = "error";
				}
			} catch (Exception e) {
				model.addAttribute("message", e.getMessage());
				target = "error";
			}

		}
		return target;
	}

	@RequestMapping(value = "getDetail", method = RequestMethod.POST)
	public ModelAndView getDetail(@RequestParam("traineeId") int traineeId)
			throws Exception {

		ModelAndView mv = new ModelAndView();
		try {
			TraineeBean traineeBean = traineeService.traineeDetail(traineeId);
			mv.addObject("trainee", traineeBean);
			mv.addObject("message", "Deleted");
			mv.setViewName("delete");
		} catch (Exception e) {
			mv.addObject("message", e.getMessage());
			mv.setViewName("error");
		}

		return mv;
	}

	@RequestMapping(value = "deleteDetail", method = RequestMethod.POST)
	public ModelAndView deleteDetail(@RequestParam("traineeId") int traineeId)
			throws Exception {

		ModelAndView mv = new ModelAndView();
		TraineeBean traineeBean = new TraineeBean();
		try {
			traineeBean = traineeService.deleteDetail(traineeId);
			if (traineeBean != null) {
				mv.addObject("message", "Record deleted");
				mv.addObject("trainee", traineeBean);
				mv.setViewName("success");
			}else{
				mv.addObject("message", "Record not found");
				mv.setViewName("error");
			}
		} catch (Exception e) {
			mv.addObject("message", e.getMessage());
			mv.setViewName("error");
		}

		return mv;
	}

	@RequestMapping("retrieveAll")
	public ModelAndView getAllDetails() throws Exception {

		ModelAndView mv = new ModelAndView();
		try {
			List<TraineeBean> list = traineeService.retrieveAllDetails();
			mv.addObject("list", list);
			mv.setViewName("viewAll");
		} catch (Exception e) {
			mv.addObject("message", e.getMessage());
			mv.setViewName("error");
		}

		return mv;
	}

	@RequestMapping(value = "retrieveTrainee", method = RequestMethod.POST)
	public ModelAndView getTraineeDetail(
			@RequestParam("traineeId") int traineeId) throws Exception {
		ModelAndView mv = new ModelAndView();
		try {
			TraineeBean traineeBean = traineeService.traineeDetail(traineeId);
			mv.addObject("trainee", traineeBean);
			mv.addObject("message", "Deleted");
			mv.setViewName("viewDetail");
		} catch (Exception e) {
			mv.addObject("message", e.getMessage());
			mv.setViewName("error");
		}

		return mv;
	}
	
	
	@RequestMapping(value = "getModifyDetail", method = RequestMethod.POST)
	public ModelAndView getModifyDetail(@RequestParam("traineeId") int traineeId)
			throws Exception {

		ModelAndView mv = new ModelAndView();
		try {
			TraineeBean traineeBean = traineeService.traineeDetail(traineeId);
			mv.addObject("trainee", traineeBean);
			mv.addObject("message", "Deleted");
			mv.setViewName("modify");
		} catch (Exception e) {
			mv.addObject("message", e.getMessage());
			mv.setViewName("error");
		}

		return mv;
	}

	@RequestMapping(value = "modifyDetail", method = RequestMethod.POST)
	public ModelAndView modifyDetail(@ModelAttribute("trainee") TraineeBean bean)
			throws Exception {

		ModelAndView mv = new ModelAndView();
		boolean isUpdated = false;
		try {
			isUpdated = traineeService.modifyDetail(bean);
			if (isUpdated) {
				mv.addObject("message", "Record Updated");
				mv.addObject("trainee", bean);
				mv.setViewName("success");
			}else{
				mv.addObject("message", "Record not found");
				mv.setViewName("error");
			}
		} catch (Exception e) {
			mv.addObject("message", e.getMessage());
			mv.setViewName("error");
		}

		return mv;
	}
}

package com.cg.dao;

import java.util.List;

import com.cg.bean.TraineeBean;

public interface ITraineeDao {

	boolean adddetails(TraineeBean traineeBean)  throws Exception ;

	TraineeBean traineeDetail(int traineeId) throws Exception ;
	
	TraineeBean deleteDetail(int traineeId) throws Exception ;
	
	List<TraineeBean> retrieveAllDetails() throws Exception;
	
	boolean modifyDetail(TraineeBean traineeBean) throws Exception ;
}

package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.TraineeBean;

@Repository
@Transactional
public class TraineeDao implements ITraineeDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public boolean adddetails(TraineeBean traineeBean) throws Exception {
		
		boolean isAdded = false;
		
		try {
			entityManager.persist(traineeBean);
			entityManager.flush();
			isAdded = true;
		} catch (Exception e) {
			
			throw new Exception("Unable to persist\n\n" + e.getMessage());

		}
		
		return isAdded;
	}


	@Override
	public TraineeBean traineeDetail(int traineeId) throws Exception {
		
		TraineeBean traineeBean = null;
		
		try {
			traineeBean = entityManager.find(TraineeBean.class,traineeId);

		} catch (Exception e) {
			
			throw new Exception("Unable to persist\n\n" + e.getMessage());

		}
		
		return traineeBean;
	}


	@Override
	public TraineeBean deleteDetail(int traineeId) throws Exception {
		TraineeBean traineeBean = null;
		
		try {
			traineeBean = entityManager.find(TraineeBean.class,traineeId);
			if(traineeBean!=null){
				entityManager.remove(traineeBean);
			}
		} catch (Exception e) {
			
			throw new Exception("Unable to persist\n\n" + e.getMessage());

		}
		
		return traineeBean;
	}


	@Override
	public List<TraineeBean> retrieveAllDetails() throws Exception {
		
		TraineeBean traineeBean = null;
		List<TraineeBean> list = new ArrayList<TraineeBean>();
		
		try {
			Query qry = entityManager.createQuery("SELECT t FROM TraineeBean t");
			
			list = qry.getResultList();
			
		} catch (Exception e) {
			
			throw new Exception("Unable to persist\n\n" + e.getMessage());

		}
		
		return list;
	}


	@Override
	public boolean modifyDetail(TraineeBean bean) throws Exception {
		
		boolean isUpdated = false;
		try {
	
				entityManager.merge(bean);
				entityManager.flush();
				isUpdated = true;
		} catch (Exception e) {
			
			throw new Exception("Unable to persist\n\n" + e.getMessage());

		}
		
		return isUpdated;
	}

	
}

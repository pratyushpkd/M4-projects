package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.TraineeBean;
import com.cg.dao.ITraineeDao;

@Service
public class TraineeService implements ITraineeService {

	@Autowired
	ITraineeDao traineeDao;
	
	

	public ITraineeDao getTraineeDao() {
		return traineeDao;
	}

	public void setTraineeDao(ITraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

	@Override
	public boolean adddetails(TraineeBean traineeBean) throws Exception{
		
		return traineeDao.adddetails(traineeBean);
	}

	@Override
	public TraineeBean traineeDetail(int traineeId) throws Exception{
		
		return traineeDao.traineeDetail(traineeId);
	}

	@Override
	public TraineeBean deleteDetail(int traineeId) throws Exception{
		
		return traineeDao.deleteDetail(traineeId);
	}

	@Override
	public List<TraineeBean> retrieveAllDetails() throws Exception {
		
		return traineeDao.retrieveAllDetails();
	}

	@Override
	public boolean modifyDetail(TraineeBean traineeBean) throws Exception {
		
		return traineeDao.modifyDetail(traineeBean);
	}
	
	
}
